export class PlantInfoData {
    ind_gen_name:string="Test1";
 ind_gen_ddlcategory:string="1";
      ind_gen_vender:string="Test1";
      ind_gen_existing_part_id:string="Test1";
      ind_gen__district:string="2";
      ind_reg_ofc:string="Test1";
      ind_gen_caaqme:string="Test1";
      ind_gen_cemc:string="Test1";
      ind_gen_no_of_cemes:string="Test1";
      ind_gen_prim_cont_pername:string="Test1";
      ind_gen_prim_design:string="Test1";
      ind_gen_prim_phone:string="Test1";
      ind_gen_prim_email:string="Test1";
      ind_gen_security_cont_person_name:string="Test1";
      ind_gen_security_cont_degn:string="Test1";
      ind_gen_security_cont_phone:string="Test1";
      ind_gen_security_cont_email:string="Test1";
      ind_gen_address:string="Test1";

      ind_network_conn_data_trans:string="1";
      ind_network_con_historical_data_activity:string="2";

     ind_network_con_station_name:string="";
     ind_network_con_monitoring_typ:string="";


     title1:string="";
     title2: string="";
     title3:string="";


    
    ind_network_con_process_attached: string="";
    ind_network_con_vendor:string="";
    ind_network_con_analyser_make: string="";
    ind_network_con_analyser_model:string="";
    ind_network_con_analyser_serial_number:string="";
    ind_network_con_device_imei_number:string="";
    ind_network_con_mac_id: string="";
    ind_network_con_measurement_range_min: string="";
     ind_network_con_measurement_range_max:string="";
    ind_network_con_parameter: string="";
    ind_network_con_unit: string="";
    ind_network_con_certification: string="";
    ind_network_con_longitude: string="";
    ind_network_con_latitude: string="";
    ind_network_con_measurement_principle: string="";
    ind_network_con_stack_height: string="";
    ind_network_con_stack_diameter:string="";
    ind_network_con_stack_velocity: string="";
    ind_network_con_flue_gas_discharge_rate_m3_hr: string="";
   ind_network_con_remark:string="";
}
